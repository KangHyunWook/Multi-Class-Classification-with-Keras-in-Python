#Programmer: HYUN WOOK KANG
#Date: 2021-Feb-4

import argparse
import cv2
import numpy as np

from preprocess.Reader import *  
from models.CNN import *  
from sklearn.model_selection import *
from keras.utils import to_categorical

size=100
BATCH=10

ap = argparse.ArgumentParser()
ap.add_argument('-r', '--rootDir', required=True, default='dataset')
ap.add_argument('-s', '--save', default='trained_model')

#returns arguments
args = vars(ap.parse_args())
                      
reader = Reader()                
labelList=os.listdir(args['rootDir'])
allFiles=reader.getAllFiles(args['rootDir'])  
numOfLabels= len(labelList) #variable numOfLabels has the number of labels
print('numOfLabels', numOfLabels)
X=[] #list to store the images of the animals
y=[] #list to store the labels for the dataset X  
                 
cnt=0                 
for f in allFiles:
    img = cv2.imread(f)
    img = cv2.resize(img, (size, size))
    paths = f.split(os.path.sep)
    X.append(img) #add the image of an animal.
    for i in range(len(labelList)):
        if labelList[i]==paths[-2]:
            y.append(i) #adds label for the corresponding image

#convert the list to array
X=np.array(X)
# X=0.2126*X[:,:,:,0]+0.7152*X[:,:,:,0]+0.0722*X[:,:,:,0]
X=X/255.0
# X=X.reshape(X.shape+(1,))
y=np.array(y)
y=y.reshape(-1, 1)

y = to_categorical(y)

print(y)

#split train and test set
trainX, testX, trainY, testY = train_test_split(X, y, test_size=0.2, random_state=1)

print(trainX.shape, trainY.shape)
print(testX.shape, testY.shape)
              
cnn = CNN(size, numOfLabels)
#build CNN model
model = cnn.build()
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.fit(trainX, trainY, epochs=10, batch_size = BATCH)
_, acc = model.evaluate(testX, testY)

print("accuracy: %.2f%%"%(acc*100))    
model.save(args['save']+'.h5')
                    














